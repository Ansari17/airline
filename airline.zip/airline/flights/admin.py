from django.contrib import admin

from flights.models import Flight

# Register your models here.
admin.site.register(Flight)
